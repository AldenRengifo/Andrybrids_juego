const int potPin = A0;
const int buttonPin = 2;
const int ledPin = 13;

int lastRawButtonState = HIGH;
int stableButtonState = HIGH;
unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 25;

unsigned long lastSendTime = 0;
const unsigned long sendInterval = 20;

void setup()
{
  Serial.begin(9600);

  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, HIGH);
}

void loop()
{

  int rawButtonState = digitalRead(buttonPin);
  if (rawButtonState != lastRawButtonState)
  {
    lastDebounceTime = millis();
    lastRawButtonState = rawButtonState;
  }

  if (millis() - lastDebounceTime > debounceDelay)
  {
    stableButtonState = rawButtonState;
  }

  int isPressed = (stableButtonState == LOW) ? 1 : 0;

  int rawPotValue = analogRead(potPin);


  int angle = map(rawPotValue, 0, 1023, 0, 90);

  if (millis() - lastSendTime >= sendInterval)
  {
    Serial.print(angle);
    Serial.print(",");
    Serial.println(isPressed);

    lastSendTime = millis();
  }

  while (Serial.available() > 0)
  {
    char command = Serial.read();

    if (command == '1')
    {
      digitalWrite(ledPin, HIGH);
    }
    else if (command == '0')
    {
      digitalWrite(ledPin, LOW);
    }
  }
}